/*
 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */


#include <ie.hpp>
using namespace ie_library;

#include <complex.h>
#include <fftw3.h>

namespace ie_library{
  float log_correction(float amp, float){return log(1+amp);}
  float pow_correction(float amp, float max){return pow(amp/max,0.001);}
}

cimgf* ie_library::
get_fft_magnitude(cimgf& im,  int correction){
  cimgf tmp(im.get_channel(0));
  int w = im.width();
  int h = im.height();
  int b = im.spectrum();
  int size = w*h*sizeof(fftw_complex);
  fftw_complex *spatial = (fftw_complex*)malloc(size);
  fftw_complex *pc      = spatial;
  for(int y=0; y<h; y++)
    for(int x=0; x<w; x++)
      (*pc++) = im(x, y, 0, 0);//+I*0;

  fftw_complex *freq = (fftw_complex*)malloc(size);
  fftw_plan plan = fftw_plan_dft_2d(h, w, spatial, freq, 
				    FFTW_FORWARD, FFTW_ESTIMATE);
  fftw_execute(plan);
  fftw_destroy_plan(plan);
  free(spatial);

  cimgf* spectrum = new cimgf(im); 
  (*spectrum)=0.0;
  pc = freq;
  for(int y=0; y<h; y++){
    for(int x=0; x<w; x++){
      float re = creal(*pc);
      float im = cimag(*pc);
      (*spectrum)(x, y, 0) = sqrt(re*re+im*im);
      pc++;
    }
  }
  pt_fff pf = NULL;
  float max = spectrum->max();
  if(correction) pf = &log_correction;
  else           pf = &pow_correction;
  for(int v=0; v<h; v++)
    for(int u=0; u<w; u++){
      float val =  pf((*spectrum)(u, v, 0), max);
      for(int z=0; z<b; z++)
	(*spectrum)(u, v, 0, z) = val;
    }
  free(freq);
  return spectrum;
  
}

cimgf* ie_library::
get_histogram(cimgf& im, int bins)
{
  cimgf* h = new cimgf(bins, 1, 1, 1, 0.0);
  float size = im.width()*im.height();
  cimg_forXY(im, x, y){
    (*h)((int)floor(im(x,y)))++;
  }
  (*h) /= (float)size;
  return h;
}

cimgf* ie_library::
get_gradient_magnitude(cimgf& im) 
{  
  cimgLf Grad(im.get_gradient(0));
  cimgf* Mag = new cimgf((Grad[1].get_mul(Grad[1])+Grad[0].get_mul(Grad[0])).sqrt());
  return Mag;
}

void ie_library::
modify_images_for_histogram(cimgf& im1, cimgf& im2, int bins) {
  // minima and maxima of the two input images to obtain the range 
  // of values that must represented in the histogram.
  float min1 = im1.min()-0.1;
  float max1 = im1.max()+0.1;
  float min2 = im2.min()-0.1;
  float max2 = im2.max()+0.1;
  float max = MAXI(max1,max2);
  float min = MINI(min1,min2);
  // size of the bins
  float sizebin = (max-min)/bins; 
  // Image rescaling
  im1.assign((im1-min)/sizebin);
  im2.assign((im2-min)/sizebin);
}

cimgf ie_library::
get_patch_cpy(cimgf& im, int x, int y, int pxp){  
  return im.get_crop(MAXI(0,x-pxp),
		    MAXI(0,y-pxp), 
		    MINI(im.width()-1,x+pxp), 
		    MINI(im.height()-1,y+pxp));
}

cimgf* ie_library::
get_patch_ptr(cimgf& im, int x, int y, int pxp){
  return new cimgf(get_patch_cpy(im, x, y, pxp));
}
