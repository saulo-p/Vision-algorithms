/*
 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */

#include <ie.hpp>
using namespace ie_library;

namespace ie_library{
  const char* colorSpaceStr[]={"Lab", "YUV", "YCbCr", "LAB", "NOTFOUND"};
    
  float RGB2LMS[3][3] = {
    {0.3811, 0.5783, 0.0402},{0.1967, 0.7244, 0.0782},{0.0241, 0.1288, 0.8444}
  };
  
  float LMS2RGB[3][3] = {
    {4.4679, -3.5873, 0.1193},{-1.2186, 2.3809, -0.1624},{0.0497, -0.2439, 1.2045}
  };
  
  float LMS2lab[3][3] = {
    {0.5773, 0.5773, 0.5773},{0.4082, 0.4082, -0.8165},{0.7071, -0.7071, 0}
  };
  
  float lab2LMS[3][3] = { 
    {0.5773, 0.4082, 0.7071}, {0.5773, 0.4082, -0.7071}, {0.5773, -0.8165, 0}
  };
  
  cimgf& 
  convert(cimgf& I, float M0[3][3], double(*f)(double), float M1[3][3])
  { 
    for (int j=0; j<I.height(); ++j){
      for (int i=0; i<I.width(); ++i) {
  	float xv = 
  	  f(M0[0][0]*I(i,j,0,0)+M0[0][1]*I(i,j,0,1)+M0[0][2]*I(i,j,0,2));
  	float yv = 
  	  f(M0[1][0]*I(i,j,0,0)+M0[1][1]*I(i,j,0,1)+M0[1][2]*I(i,j,0,2));
  	float zv = 
  	  f(M0[2][0]*I(i,j,0,0)+M0[2][1]*I(i,j,0,1)+M0[2][2]*I(i,j,0,2)); 
  	I(i,j,0,0) = M1[0][0]*xv+M1[0][1]*yv+M1[0][2]*zv;
  	I(i,j,0,1) = M1[1][0]*xv+M1[1][1]*yv+M1[1][2]*zv; 
  	I(i,j,0,2) = M1[2][0]*xv+M1[2][1]*yv+M1[2][2]*zv; 
      }
    }
    return I;
  } 
}
  
cimgf& ie_library::
rgb_to(cimgf& I, int space)
{
  switch(space){
  case Lab:{
    cimg_forXYC(I, x, y, d){ if(I(x,y,0,d)==0) I(x,y,0,d)=1; }
    return convert(I, RGB2LMS, &log, LMS2lab);
  }
  case YUV:   return I.RGBtoYUV();
  case YCbCr: return I.RGBtoYCbCr();
  case LAB:   return I.RGBtoLab(); 
  default:    exit(EXIT_FAILURE); 
  } 
}

cimgf& ie_library::
to_rgb(cimgf& I, int space)
{
  switch(space){
  case Lab:   return convert(I, lab2LMS, &exp, LMS2RGB).normalize(0,255);
  case YUV:   return I.YUVtoRGB().normalize(0,255); 
  case YCbCr: return I.YCbCrtoRGB().normalize(0,255); 
  case LAB:   return I.LabtoRGB().normalize(0,255); 
  default:    exit(EXIT_FAILURE); 
  }
}

cimgf& ie_library::
to_rgb_fmt(cimgf& I, int space, const char* format, ...)
{
  ie_library::to_rgb(I, space);
  char buffer[BUFFER_SIZE];
  va_list params;
  va_start(params, format);vsprintf(buffer, format, params);va_end(params);
  I.save(buffer);
  return I;
} 


cimgf& ie_library::
variance_mean_mapping(cimgf& model, cimgf& reconstruct)
{
  float mean1 = model.mean(); 
  float var1  = sqrt(model.variance()); 
  float mean2 = reconstruct.mean(); 
  float var2  = sqrt(reconstruct.variance()); 
  float ratio = var1/(float)var2;
  reconstruct = ratio*(reconstruct-mean1)+mean2;
  return reconstruct;
}

