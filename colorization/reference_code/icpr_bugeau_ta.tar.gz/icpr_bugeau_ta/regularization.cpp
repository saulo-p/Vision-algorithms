/*
 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */

#include <ie.hpp>
using namespace ie_library; 

cimgf* ie_library::
TV_regularization(cimgf& I,  float lambda, int iter) { 
  /* define parameters */
  float tau     = 1./sqrt(8);//stepsize parameter
  float sigma   = 1./(8*tau);
  float gamma   = 0.35*lambda;
  float theta   = 0;
  int   k       = 0;

  /* initialize images */
  cimgf u0(I);
  // primal
  cimgf X0(u0);
  cimgf X1(u0);
  cimgf* Xb = new cimgf(u0);
  // dual variable
  cimgf Y0(u0.width(), u0.height(), 2, u0.spectrum(), 0.0);
  cimgf Y1(Y0);


 
  

  // initialize gradient
  cimg_forXYC(X0, x, y, c){
    if(x<X0.width()-1)
      Y1(x, y, 0, c) = (u0(x+1, y, 0, c)-u0(x, y, 0, c));
    if(y<X0.height()-1)
      Y1(x, y, 1, c) = (u0(x, y+1, 0, c)-u0(x, y, 0, c));
  }
  // primal dual chambolle pock algorithm ALG2
  while(k<iter){
    X0 = X1;
    Y0 = Y1;
    // compute prox_sF*     
    cimg_forXYC(X0, x, y, c){
      if(x<X0.width()-1)
	Y1(x, y, 0, c) = Y0(x, y, 0, c)+sigma*((*Xb)(x+1, y, 0, c)-(*Xb)(x, y, 0, c));
      else 
	Y1(x, y, 0, c) = Y0(x, y, 0, c);
      if(y<X0.height()-1)
	Y1(x, y, 1, c) = Y0(x, y, 1, c)+sigma*((*Xb)(x, y+1, 0, c)-(*Xb)(x, y, 0, c));
      else
	Y1(x, y, 1, c) = Y0(x, y, 1, c);	
      // L2 projection
      float norm =
	(sqrt(Y1(x, y, 0, c)*Y1(x, y, 0, c)+Y1(x, y, 1, c)*Y1(x, y, 1, c)));

      if(norm > 1){

	Y1(x, y, 0, c)/= norm;
	Y1(x, y, 1, c)/= norm;
      }
    }
    // compute prox_tG    
    cimg_forXYC(Y1, x, y, c){
      float divx=0, divy=0;  
      if(x>0 && x<X0.width()-1)
	divx = Y1(x, y, 0, c) - Y1(x-1, y, 0, c);
      else
	if(x==0)
	  divx = Y1(x, y, 0, c);
	else 
	  divx = -Y1(x-1, y, 0, c);

      if(y>0 && y<X0.height()-1)
	divy = Y1(x, y, 1, c) - Y1(x, y-1, 1, c);
      else
	if(y==0)
	  divy = Y1(x, y, 1, c);
	else
	  divy = -Y1(x, y-1, 1, c);    
      X1(x, y, 0, c) = 
	(X0(x, y, 0, c)+tau*(divx+divy)+tau*lambda*u0(x, y, 0, c))/(1+tau*lambda);
      
    }
    theta = 1/sqrt(1+2*gamma*tau);
    tau   = theta*tau;
    sigma = sigma/theta;
    // update
    (*Xb) = X1+theta*(X1-X0);          
    k++;
  }

  return Xb;
}















