/*
 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */

#include <ie.hpp>
using namespace ie_library;

namespace ie_library{
  enum distance { SAD=1, SSD=2 };
}

#define m_global_feature_based(l, x, y, pxp, list, img, map, feature) \
  cimgf* p          = get_patch_ptr(gray_l, x, y, pxp); \
  float feature##xy = (*p).feature(); \
  if(l==SAD) sum_list(feature##xy, map, list, &fabsf); \
  if(l==SSD) sum_list(feature##xy, map, list, &ie_library::pow2); \
  delete p;

void ie_library::
sum_list(float val, mmap& map, cimgf& list, pt_ff pf){
  int size = list.width();
  for(int i=0; i<size; i++){
    float dst = val-list(i, 0, 0, 0);
    dst = pf(dst);
    map.insert(std::pair<float, int>(dst,i));
  }
}


float ie_library::
sum_diff_list(cimgf& lp, cimgf& lq, pt_ff pf){
  int size = lp.width();
  float sum=0;
  for(int i=0; i<size; i++)
    sum += pf(lp(i,0, 0, 0)-lq(i, 0, 0, 0));
  return sum;
}

float ie_library::
sum_patch(int px, int py, cimgf& imp,
	   int qx, int qy, cimgf& imq,
	   int sX, int eX, int sY, int eY, int bands,
	   pt_sxd pf){
  int pw = imp.width(),  ph = imp.height();
  int qw = imq.width(),  qh = imq.height();
  float sum = 0;
  for(int l=sY; l<=eY; l++){
    for(int k=sX; k<=eX; k++){
      int rx = px+k, ry = py+l;
      if(rx<0||rx>=pw||ry<0||ry>=ph) continue;
      int sx = qx+k, sy = qy+l;	
      if(sx<0||sx>=qw||sy<0||sy>=qh) continue;   
      sum += pf(rx, ry, imp, sx, sy, imq, bands);
    }
  }
  return sum; 
}

float ie_library::
sum_diff(int px, int py, cimgf& ip, int qx, int qy, cimgf& iq, int b, pt_ff pf)
{
  float sum=0;
  for(int i=0;i<b;i++) sum += pf(ip(px, py, 0, i)-iq(qx, qy, 0, i));
  return sum;
}

float ie_library::
sad(int px, int py, cimgf& ip, int qx, int qy, cimgf& iq, int b)
{
  return sum_diff(px, py, ip, qx, qy, iq, b, &fabsf);
}

float ie_library::
ssd(int px, int py, cimgf& ip, int qx, int qy, cimgf& iq, int b)
{
  return sum_diff(px, py, ip, qx, qy, iq, b, &ie_library::pow2);
} 


void ie_library::
fft_magnitude(int l, int x, int y, int pxp, 
	      mmap& map, cimgLf& magnitudes, cimgf& gray_l)
{
  cimgf* p   = get_patch_ptr(gray_l, x, y, pxp);
  cimgf* fft = get_fft_magnitude(*p, 1);
  fft->normalize(0, 255);
  int nrefs = magnitudes.size();
  for(int i=0; i<nrefs; i++){
    float dst = 0;
    cimgf mag = magnitudes(i);
    if(l==SAD) dst = sum_patch(1,1,mag,1,1,*fft,1,2*pxp,1,pxp,1,&sad);
    if(l==SSD) dst = sum_patch(1,1,mag,1,1,*fft,1,2*pxp,1,pxp,1,&ssd);
    map.insert(std::pair<float, int>(dst,i));
  }
  delete p; delete fft;
}


void ie_library::
histogram_difference(int l, int x, int y, int pxp, 
		     mmap& map, cimgLf& histograms, cimgf& gray, pt_cf pf)
{
  cimgf* p  = get_patch_ptr(gray, x, y, pxp);  
  int nbins = histograms(0).width();
  cimgf* hp = pf(*p, nbins);
  int nrefs = histograms.size();
  for(int i=0; i<nrefs; i++){
    float dst = 0;
    cimgf hq  = histograms(i);
    if(l==SAD) dst = sum_diff_list(*hp,hq,&fabsf);
    if(l==SSD) dst = sum_diff_list(*hp,hq,&ie_library::pow2);
    map.insert(std::pair<float, int>(dst,i));
  }
  delete p; delete hp;
}

void ie_library::
variance(int l, int x, int y, int pxp, 
	 mmap& map, cimgf& variances, cimgf& gray_l)
{
  m_global_feature_based(l, x, y, pxp, variances, gray_l, map, variance);
}
 
