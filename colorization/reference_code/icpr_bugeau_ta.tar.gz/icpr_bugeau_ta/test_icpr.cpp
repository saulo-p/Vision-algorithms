/*
 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */


#include <float.h>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <map>

#include <ie.hpp>
using namespace ie_library;
using namespace std;
#define epsilon 0.0001


struct color{
  float alpha;
  float beta;
};
typedef struct color Color;


void pca(vector<Color>& listc, Color* col) {
  Color meanc;
  meanc.alpha = 0;
  meanc.beta = 0;
  int size = listc.size();
  vector<Color> listc2 = listc;
  for (int i=0; i<size; ++i) {
    meanc.alpha += listc[i].alpha;
    meanc.beta += listc[i].beta;
  }
  meanc.alpha /= size;
  meanc.beta /= size;

  for (int i=0; i<size; ++i) {
    listc2[i].alpha = listc[i].alpha-meanc.alpha;
    listc2[i].beta = listc[i].beta-meanc.beta;
  }

  float cova = 0, covb = 0, covab = 0;
  for (int i=0; i<size; ++i) {
    cova += listc2[i].alpha*listc2[i].alpha/(size);
    covb += listc2[i].beta*listc2[i].beta/(size);
    covab += listc2[i].alpha*listc2[i].beta/(size);
    
  }
  //Projection
  float val1 = cova+covb+sqrt((cova+covb)*(cova+covb)+4*(covab*covab-cova*covb));
  float vec1a = 1;
  float vec1b = (val1-cova)/covab;
  

  std::multimap<float, int> coord;
  for (int i=0; i<size; ++i)  {
    coord.insert(pair<float, int>(vec1a*listc2[i].alpha+vec1b*listc2[i].beta, i));
 
  }

  multimap<float, int>::iterator iterator = coord.begin();
  int ind = 0;
  int mid = (*iterator).second;
  while (ind < size/2 ) {
    ind++;
    iterator++;
    mid = (*iterator).second;
    
  }

  col->alpha = listc[mid].alpha;
  col->beta = listc[mid].beta;
  
}


void regularize_median(cimgf& Ic,const char* dirout, string name, int space, float lambda, int iter) {

  cimgf Tmp(Ic);
  cimgf Init(Ic);
  to_rgb(Tmp,(colorSpaceName)space);
  savef(Tmp,"%s%s.png",dirout,name.c_str()); 

  Ic.assign(Init);
  Tmp.assign(Ic.get_channels(1,2));
  cimgf* regul2 = TV_regularization(Tmp, lambda, iter);
  Ic.draw_image(0,0,0,1, (*regul2));
  to_rgb(Ic,(colorSpaceName)space);
  savef(Ic,"%s%s_regul0.png",dirout,name.c_str()); 

  delete regul2;
}






int main(int argc, char* argv[]) {
  const char* inp1 = cimg_option("-i1",(char*)0,"input grey");
  const char* inp2 = cimg_option("-i2",(char*)0,"input color");
  const char* dirout = cimg_option("-od",(char*)"./","output directory");
  const int space = cimg_option("-color",0,"Color space: \n 0: Lalphabeta \n 1: YUV \n 2: YCbCr");
  const int nsamp= cimg_option("-nsamp",2000,"number of candidates");
  float lambda         = cimg_option("-l", 2, "lambda value for TV regularization"); 
  float iter           = cimg_option("-it",100, "number of iterations"); 
  const int   kbest = cimg_option("-kbest",5,"number of candidates");
 

  int pxp = 5;
  
  cimgf I1(inp1);
  cimgf I2(inp2); 

  /***********************************************************/
  /* COLOR SPACE CONVERTION                                  */
  /***********************************************************/
  rgb_to(I1, (colorSpaceName)space);
  rgb_to(I2, (colorSpaceName)space);

  /***********************************************************/
  /* HISTOGRAM EQUALIZATION                                  */
  /***********************************************************/  
  cimgf I01(I1.get_channel(0));  
  cimgf I02(I2.get_channel(0)); 
  variance_mean_mapping(I01, I02); 

  /***********************************************************/
  /* RANDOMLY EXTRACT PATCHES */
  /***********************************************************/  
  cimgLi* points;
  int nrefs = 0;
  points = get_random_points(I2.width(), I2.height(), pxp, nsamp);
  nrefs += points->size(); 
  printf("nrefs=%d\n",nrefs);
  
  /***********************************************************/
  /* PRE-COMPUTE FEATURES */
  /***********************************************************/ 
  cimgLf patches;
  cimgf  tmp(2*pxp+1, 2*pxp+1, 1, 1, 0.0);
  patches.assign(points->size(),tmp);

  cimgLf magnitudes;
  magnitudes.assign(patches);

  cimgLf histograms;
  int nbins = 8;
  histograms.assign(points->size(),nbins,1,1,1, 0.0);

  cimgf variances;
  variances.assign(points->size(), 1, 1, 1, 0.0);
 

  cimgf* gray_mag = get_gradient_magnitude(I01);
  cimgf* color_mag = get_gradient_magnitude(I02);
  modify_images_for_histogram(*gray_mag, *color_mag, nbins);

  cimgf gray_h(I01);
  cimgf color_h(I02);
  modify_images_for_histogram(gray_h, color_h, nbins);

  for(unsigned int i=0; i<points->size(); i++){
    int x = (*points)(i)(0,0,0,0), y = (*points)(i)(0,0,0,1);
    
    cimgf *p  = get_patch_ptr(I02, x, y, pxp);
    patches(i)  = (*p);
    variances(i)   = (*p).variance();

    magnitudes(i)  = (* get_fft_magnitude(*p, 1)).normalize(0,255);

    p  = get_patch_ptr(color_h, x, y, pxp);
    histograms(i) = (*get_histogram(*p, nbins)); 
 

    delete p;

  }
  

  /***********************************************************/
  /* Copy/Paste */
  /***********************************************************/ 
  int nfeatures = 3; // number of features

  mmap* map = new mmap[nfeatures];



  vector<Color> listc; 
  cimgf Ic(I1);

  int ht = I1.height(); 
  int wt =  I1.width();
  for(int y=0; y<ht; y++){  
    for(int x=0; x<wt; x++){ 

 
      // // variance
      variance(1, x, y, pxp, map[0],variances, I01);


      //histogram
      histogram_difference(1, x, y, pxp,map[1],  histograms, gray_h, &get_histogram);

      //fft
      fft_magnitude(1, x, y, pxp, map[2], magnitudes, I01);

      for(int t=0; t<nfeatures; t++){
	mmap::iterator it = (map[t]).begin();
	for(int i=0;i<kbest;i++){
	  int best = (*it).second;
	  it++;
	  int qx =  (*points)(best)(0,0,0,0);
	  int qy =  (*points)(best)(0,0,0,1);
	  Color c;
	  c.alpha = I2(qx, qy, 0, 1);
	  c.beta = I2(qx, qy, 0, 2);
	  listc.push_back(c);

	}
      }

      
      Color* col = (Color*)malloc(sizeof(Color));
      pca(listc, col) ; 
      Ic(x, y, 0, 1) = col->alpha;
      Ic(x, y, 0, 2) = col->beta;
      free(col);
    
      listc.clear(); 
      for(int t=0; t<nfeatures; t++){
	map[t].clear();
      }

    }
  }



  delete[] map;
  delete points;





  /***********************************************************/
  /*   REGULARIZATION */
  /***********************************************************/ 
  string name  = "out";
  regularize_median(Ic, dirout, name, space, lambda, iter);







  delete gray_mag;
  delete color_mag;

  return EXIT_SUCCESS;
}


