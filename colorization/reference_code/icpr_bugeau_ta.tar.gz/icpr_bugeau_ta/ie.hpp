/**
 * IMAGEEDITING LIBRARY: 
 * provides some functions to for image editing processing based on CImg library
 * \file ie.hpp  
 * \brief main header
 * \date 2012 first version 

 *
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 */

#ifndef IMAGEEDIDING_HPP
#define IMAGEEDITING_HPP

#include <CImg.h>
#include <float.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
using namespace cimg_library;

#include <map>

/* define some colors for UI */
namespace ie_library{
  static const unsigned char white[]    = { 255,255,255 };
  static const unsigned char black[]    = { 0,0,0 };
  static const unsigned char gray[]     = { 128,128,128 };
  static const unsigned char red[]      = { 255,0,0 };
  static const unsigned char green[]    = { 0,255,0 };
  static const unsigned char blue[]     = { 0,0,255 };
  static const unsigned char cyan[]     = { 0,255,255 };
  static const unsigned char magenta[]  = { 255,0,255 };
  static const unsigned char yellow[]   = { 255,255, 0 };
  static const unsigned char purple[]   = { 128,0, 128 };
  static const unsigned char teal[]     = { 0, 128, 128 };
  static const unsigned char maroon[]   = { 128, 0, 0 };
  static const unsigned char lime[]     = { 0, 128, 0 };
}

/* constants and types */
namespace ie_library{

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 4096
#endif

#ifndef MINI
#define MINI(X,Y) ((X) < (Y) ?  (X) : (Y))
#endif

#ifndef MAXI
#define MAXI(X,Y) ((X) > (Y) ?  (X) : (Y))
#endif

#ifndef PI
#define PI 3.14159265358979323846
#endif
  
  /* define some typedefs */
  typedef CImg<float>        cimgf;
  typedef CImg<int>          cimgi;
  typedef CImgList<float>    cimgLf;  
  typedef CImgList<int>      cimgLi;  
  typedef unsigned char      uchar;
  
  typedef float (*pt_sxd)(int, int, cimgf&, int, int, cimgf&, int);
  typedef float (*pt_ff) (float);
  typedef float (*pt_fff)(float, float);
  typedef cimgf* (*pt_cf)(cimgf&, int);
  
  typedef std::multimap<const float, int> mmap;  
  typedef mmap::iterator mmapiter;  

}

/** 
 * image transformation functions
 * i.e. colorspace, mapping, etc.
 */
namespace ie_library{
  enum colorSpaceName{
    Lab,
    YUV,
    YCbCr,
    LAB, 
    NOTFOUND
  };

  /**
   * \brief convert rgb image to specified colorspace (in-place)
   * \param input image
   * \param colorSpaceName (see enum)
   * \return the reference of the input image
   */
  extern cimgf& 
  rgb_to(cimgf&, int); //tested

  /**
   * \brief convert image form specified colorspace to rgb (in-place)
   * the image is normalized in [0, 255]
   * \param input image
   * \param colorSpaceName (see enum)      
   * \return the reference of the input image
   */
  extern cimgf&
  to_rgb(cimgf&, int);  //tested

  /**
   * \brief convert image form specified colorspace to rgb (in-place)
   * the image is normalized in [0, 255] and save the result into
   * specfied file name using fprintf syntax
   * \param input image
   * \param colorSpaceName (see enum)
   * \param printf style fomatted string
   * \param va_list
   * \return the reference of the input image
   */
  extern cimgf&
  to_rgb_fmt(cimgf&, int, const char*, ...);  //tested

  /**
   * \brief map variance and mean from an image  model into a 
   * recontructed image (in-place)
   * \param image model
   * \param reconstructed image
   * \return the reference of the recontructed image
   */
  extern cimgf& 
  variance_mean_mapping(cimgf&, cimgf&) ; //tested


}

/** 
 * Extract features functions from images
 */
namespace ie_library{

  /**
   * \brief compute FFT magnitude spectrum. The spectrum
   * is not normalize and not shift
   * \param input image
   * \param correction (0: pow(mag/max, 0.001), 1: log)
   * \return the FFT magnitude
   */  
  extern cimgf* 
  get_fft_magnitude(cimgf&, int);  //tested

  /**
   * \brief compute histogram from input image. Input is supposed to 
   * be an image containing only 1 channel. The computed histogram
   * is an image with width = bins
   * \param input image
   * \param number of bins
   * \return the histogram
   */  
  extern cimgf*
  get_histogram(cimgf&, int);  //tested


  /**
   * \brief compute magnitude of the gradients of the input image. Input 
   * is supposed to be an image containing only 1 channel.
   * \param input image
   * \param number of bins
   * \return the magnitude image
   */ 
  extern cimgf*
  get_gradient_magnitude(cimgf&);

  /**
   * \brief Modify the two input images so that their histograms 
   * will have the same range of values. The two input images are supposed 
   * to be images containing only 1 channel.
   * \param first input image
   * \param second input image
   * \param number of bins
   * \return void
   */ 
  extern void 
  modify_images_for_histogram(cimgf&, cimgf&, int);

  /**
   * \brief get a square patch from input image
   * \param input image
   * \param x position of the central pixel
   * \param y position of the central pixel
   * \param patch half size
   * \return a copy of the patch 
   */
  extern cimgf
  get_patch_cpy(cimgf&, int, int, int); //tested

  /**
   * \brief get a square patch from input image
   * \param input image
   * \param x position of the central pixel
   * \param y position of the central pixel
   * \param patch half size
   * \return a pointer on the copied  patch 
   */
  extern cimgf*
  get_patch_ptr(cimgf&, int, int, int); //tested

}


/** 
 * Distances functions
 */
namespace ie_library{
  
  /**
   * \brief loop over a list and return the sum of difference
   * between val and list(i, 0, 0, ). List is supposed to be 
   * an 1D image, where the number of list element corresponds 
   * to the image width. computation are stored in a multimap
   * \param the value 
   * \param the multimap
   * \param the list 
   * \param function to apply on the difference
   */
  extern void
  sum_list(float, mmap&, cimgf&, pt_ff);

  extern float
  sum_diff_list(cimgf&, cimgf&, pt_ff);

  /**
   * \brief loop over a patch and return the sum of difference
   * between patch centered on x, y and the centered on qx, qy
   * \param x1 of central pixel of patch 1
   * \param y1 of central pixel of patch 1
   * \param image containing patch 1
   * \param x2 of central pixel of patch 2
   * \param y2 of central pixel of patch 2
   * \param image containing patch 2
   * \param start index on Y
   * \param end index on Y
   * \param start index on X
   * \param end index on X
   * \param number of channel to compute (1: for grayscale)
   * \param function to apply on the difference
   * \return the sum
   */
  extern float  //tested
  sum_patch(int,int,cimgf&,int,int,cimgf&,int,int,int,int,int,pt_sxd);

  extern float //tested
  sum_diff(int, int, cimgf&, int, int, cimgf&, int, pt_ff); //tested

  extern float //tested
  sad(int, int, cimgf&, int, int, cimgf&, int);
  
  extern float //tested
  ssd(int, int, cimgf&, int, int, cimgf&, int); 

  extern void //not tested but trust luminance test
  fft_magnitude(int, int, int, int, mmap&, cimgLf&, cimgf&);

  extern void //not tested but trust mean test
  variance(int, int, int, int, mmap&, cimgf&, cimgf&);

  extern void  //tested
  histogram_difference(int, int, int, int, mmap&, cimgLf&, cimgf&, pt_cf);

}


/** 
 * Some auxilary functions 
 */
namespace ie_library{
  
  /**
   * \brief compute an uniform random set of 2D points defined as
   * the central pixels of the specified pacth size
   * \param image width
   * \param image height
   * \param patch half size
   * \param number of points
   * \return a pointer on an image list where each image is considered
   * as a 1D image with 2 pixels containing at 0: the x ans at 1 the
   * y coordinates
   */
  extern cimgLi*
  get_random_points(int, int, int, int); //tested
  
  /**
   * \brief reconstruct an image from a set points defined as
   * the central pixels of the specified pacth size
   * \param the initial image
   * \param the set of points
   * \param patch half size
   * \return reconstructed image
   */
  extern cimgf*
  get_patches_image(cimgf&, cimgLi&, int); //tested
  
  /**
   * \brief draw a boudary on an input image as the external boundary of
   * a patch centered on the (x,y) pixel with specified color
   * \param the input image
   * \param x  set of points
   * \param patch half size
   * \param a color
   * \return reference of the input image
   */
  extern cimgf&
  draw_patch_boundaries(cimgf&, int, int, int, const uchar*); //tested

  /**
   * \brief identity function
   * \param the input value
   * \return the input value 
   */
  extern float 
  identity(float); //tested

  /**
   * \brief square function 
   * \param the input value
   * \return the squared value 
   */
  extern float 
  pow2(float); //tested

  /**
   * \brief save the image with the 
   * specfied file name using fprintf syntax
   * \param input image
   * \param printf style fomatted string
   * \param va_list
   * \return the reference of the input image
   */
  extern cimgf& 
  savef(cimgf&, const char*, ...);
  
}

/** 
 * Regularization functions
 */
namespace ie_library{
  
  /**
   * \brief compute the total variation regularization on the input image 
   * from the primal dual chambolle pock algorithm ALG2. The energy that 
   * is minimized is as follows:
   * @f$ min_u \int |L(x)\nabla u(x)| + \frac{\lambda}{2}\|u(x)-u_0(x)\|^2 @f$
   * where L is a function varying spatially that decreases or increases 
   * the influence of the data term.
an uniform random set of 2D points defined as
   * the central pixels of the specified pacth size
   * \param input image @f$ u_0 @f$
   * \param weight image @f$ L @f$
   * \param parameter @f$ \lambda @f$ 
   * \param number of iterations 
   * \return a pointer on the regularized image @f$ u @f$
   */
  extern cimgf*
  TV_regularization(cimgf&, float, int); //tested
}


/** 
 * Convert a variable to a string (mainly used to convert int to string)
 * 
 * @param Value variable to convert
 * 
 * @return a string
 */
template<typename T>
std::string to_string( const T & Value )
{
    // utiliser un flux de sortie pour créer la chaîne
    std::ostringstream oss;
    // écrire la valeur dans le flux
    oss << Value;
    // renvoyer une string
    return oss.str();
}

#endif /* IMAGEEDITING */
