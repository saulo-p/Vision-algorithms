/*
 * Code by Aurelie Bugeau and Vinh Tong Ta (University Bordeaux - Labri)
 * 
 * Patch-based Image Colorization Bugeau A., Ta V.-T. Dans Proceedings - International Conference on Pattern Recognition, Japon (2012) 
 *
 */

#include <ie.hpp>
using namespace ie_library;


cimgLi* ie_library::
get_random_points(int w, int h, int pxp, int nsample){
  srand(time(NULL)); 
  int nxn = (int)round(sqrt((w-2*pxp-1)*(h-2*pxp-1)/nsample));
  int col = ((w-2*pxp-1)/nxn), row = ((h-2*pxp-1)/nxn), cpt = 0;
  cimgi tmp(1, 1, 1, 2, 0);
  cimgLi* points = new cimgLi(row*col, tmp);
  for(int j=0; j<row; j++){
    for(int i=0; i<col; i++){
      int px = i*nxn+rand()%nxn+pxp, py = j*nxn+rand()%nxn+pxp;
      while((px<pxp) || (py<pxp) || (px>w-pxp) || (py>h-pxp)){
	px = j*nxn+rand()%nxn; py = i*nxn+rand()%nxn;	
      }
      (*points)(cpt)(0,0,0,0) = px; (*points)(cpt)(0,0,0,1) = py; cpt++;
    }
  }
  return points;
}

cimgf* ie_library::
get_patches_image(cimgf& I, cimgLi& points, int pxp){
  unsigned int count = points.size();
  int w = I.width();
  int h = I.height();
  int b = I.spectrum();  
  cimgf* patches = new cimgf(I);
  (*patches) = 255;
  for(unsigned int i=0; i<count; i++){
    int x = points(i)(0,0,0,0);
    int y = points(i)(0,0,0,1);   
    for(int l=-pxp; l<=pxp; l++){
      for(int k=-pxp; k<=pxp; k++){
	int px = x+k;
	int py = y+l;
	if(px<0||px>=w||py<0||py>=h) continue;
	for(int c=0; c<b; c++) 
	  (*patches)(px, py, 0, c) = I(px, py, 0, c);
      }
    }
  }    
  return patches;
}

cimgf& ie_library::
draw_patch_boundaries(cimgf& I, int x, int y, int pxp, const uchar* col){
  int x0 = x-pxp-1, y0 = y-pxp-1, x1 = x+pxp+1, y1 = y+pxp+1;

  if(x>pxp && x<I.width()-pxp && y>pxp&& y<I.height()-pxp){	
    I.draw_line(x0, y0, x1, y0, col);
    I.draw_line(x1, y0, x1, y1, col);
    I.draw_line(x1, y1, x0, y1, col);
    I.draw_line(x0, y1, x0, y0, col);
  }      
  return I;
}


float ie_library::identity(float val){return val;}

float ie_library::pow2(float val){return val*val;}

cimgf& ie_library::
savef(cimgf& I, const char* format, ...)
{
  char buffer[BUFFER_SIZE];
  va_list params;
  va_start(params, format);vsprintf(buffer, format, params);va_end(params);
  I.save(buffer);
  return I;
} 


// map.insert(pair<float, int>(0,nrefs+1));  
// multimap<float, int>::iterator itmin = map.begin();
// multimap<float, int>::iterator itmax = map.end();
// multimap<float, int>::iterator it = map.begin();
// float diff = 1./((*itmax).first-(*itmin).first);
// for(it = map.begin(); it !=map.end(); it++){
//   int c = (*it).second;
//   float v = (*it).first;
//   v = diff*(v-(*itmin).first);
//   map.erase(it);
//   map.insert(pair<float, int>(v,c));
// }
   
